@echo off
chcp 65001 >nul
cd /d "%~dp0"
start "" "%~dp0控制棒矩阵.html"
